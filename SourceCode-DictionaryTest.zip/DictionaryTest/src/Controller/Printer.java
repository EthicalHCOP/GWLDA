/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Controller;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;

/**
 *
 * @author Usuario
 */
public class Printer {
    
    private static String Index1="[+] ";
    private static String Index2="[-] ";
    private static String Index3="[!] ";
    private static String Index4="[*] ";
    
    private static String string ="";
    //private static String [] outs = new String[];
    
    public void print(Integer Index, String Message, String file, Boolean chsave) throws IOException{
        switch(Index){
            case 1:
                // success
                Message = Index1+Message;
            break;
            case 2:
                //fail
                Message = Index2+Message;
            break;
            case 3:
                //error
                Message = Index3+Message;
            break;
            case 4:
                //notification
                Message = Index4+Message;
            break;
        }
        System.out.println(Message);
        if (chsave) {
            WriteLog(file, Message);
        }
    }
    
    public String CreateTxt(String Url, Boolean chsave) throws IOException{
        Date date = new Date();
        String FName = "";
        DateFormat dateFormat = new SimpleDateFormat("ddMMyyyy");
        DateFormat hourFormat = new SimpleDateFormat("HHmmss");
        FName = dateFormat.format(date) + hourFormat.format(date);
        String ruta = System.getProperty("user.dir")+"\\"+"Logs\\"+FName+".txt";
        File archivo = new File(ruta);
        if(!archivo.exists()) {
            archivo.createNewFile();
            print(1, "A new file, has been created.", ruta, chsave);
        }
        return ruta;
    }
    
    public void WriteLog(String filein, String Textin) throws IOException{
        FileReader f = new FileReader(filein);
        BufferedReader b = new BufferedReader(f);
        String sCadena;
        save(filein, Textin);
        while ((sCadena = b.readLine())!=null) {
            this.string = this.string + sCadena + System.getProperty("line.separator");
            save(filein,this.string);
            break;
        }
    }
    
    public static void save(String filein, String Textin) throws IOException{
        FileWriter f = new FileWriter(filein);
        BufferedWriter b = new BufferedWriter(f);
        try {
            b.append(Textin);
            b.newLine();
            b.flush(); 
        } catch (Exception e) {
            System.out.println(e.getMessage());
        }
        b.close();
    }
}